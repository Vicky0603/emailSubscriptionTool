import React, {Component} from 'react';

/*
Holds group of emails inside of it
*/
